import json, re, inspect, hashlib, warnings, zipfile, csv
from pathlib import Path
from datetime import datetime
import holidays
from babel import Locale
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.table import Table, TableStyleInfo

warnings.filterwarnings('ignore')
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='/workspace/output')
parser.add_argument('--countries-source',default=str(Path(__file__).with_name('countries_source_snapshot.json')) if Path(__file__).with_name('countries_source_snapshot.json').exists() else '/workspace/work/countries.json')
args=parser.parse_args()
OUT=Path(args.output); OUT.mkdir(parents=True,exist_ok=True)
ROOT=OUT/'HappyRoom_Global_Calendar'; ROOT.mkdir(exist_ok=True)
YEARS=[2026,2027]
vi=Locale('vi')
countries=[c for c in json.load(open(args.countries_source)) if c['unMember'] or c['cca2'] in ('VA','PS')]
CONT={'Asia':'Châu Á','Europe':'Châu Âu','Africa':'Châu Phi','Oceania':'Châu Đại Dương','North_America':'Bắc Mỹ','South_America':'Nam Mỹ'}
def continent(c):
    if c['region']=='Americas': return 'South_America' if c['subregion']=='South America' else 'North_America'
    return c['region']
def slug(s): return re.sub('[^a-zA-Z0-9_-]+','_',s).strip('_')

# Editorial summaries describe broad meaning; they are not source quotations.
RULES=[
 (r'lunar new year|chinese new year|spring festival|tết|tet holiday','Tết âm lịch','Đón năm mới theo lịch truyền thống; dịp đoàn tụ gia đình, tưởng nhớ tổ tiên và gửi lời chúc đầu năm.','Lễ hội','Vui tươi'),
 (r'new year|new year’s|new year\'s','Năm mới','Đánh dấu khởi đầu năm mới theo hệ lịch của cộng đồng tổ chức.','Lễ hội','Vui tươi'),
 (r'eid.*fitr|fitr|korité|korite|ramazan bayram','Eid al-Fitr','Lễ kết thúc tháng Ramadan của người Hồi giáo, gắn với cầu nguyện, sẻ chia và sum họp.','Tôn giáo','Theo cộng đồng'),
 (r'eid.*adha|adha|sacrifice|kurban','Eid al-Adha','Lễ hiến sinh của người Hồi giáo, nhấn mạnh đức tin, sự sẻ chia và hỗ trợ người khó khăn.','Tôn giáo','Theo cộng đồng'),
 (r'ashura|ashoura','Ashura','Ngày có ý nghĩa khác nhau giữa các cộng đồng Hồi giáo; với nhiều người Shia là dịp tưởng niệm Imam Husayn.','Tưởng niệm','Trang trọng'),
 (r'prophet|mawlid|milad|maulid','Ngày sinh Nhà tiên tri','Dịp tưởng nhớ sự ra đời của Nhà tiên tri Muhammad; cách thực hành khác nhau giữa các cộng đồng.','Tôn giáo','Theo cộng đồng'),
 (r'isra|mi.raj|ascension of.*muhammad','Isra và Mi’raj','Tưởng nhớ hành trình đêm và sự thăng thiên của Nhà tiên tri Muhammad trong truyền thống Hồi giáo.','Tôn giáo','Theo cộng đồng'),
 (r'ramadan|ramazan','Ramadan','Thời gian thiêng liêng của người Hồi giáo, gắn với chay tịnh, cầu nguyện và bác ái.','Tôn giáo','Theo cộng đồng'),
 (r'christmas|nativity','Giáng sinh','Kỷ niệm sự ra đời của Chúa Giêsu trong Kitô giáo; nhiều cộng đồng cũng tổ chức sum họp gia đình.','Tôn giáo','Theo cộng đồng'),
 (r'good friday|holy friday','Thứ Sáu Tuần Thánh','Tưởng niệm cuộc khổ nạn và sự qua đời của Chúa Giêsu; phù hợp nội dung trang trọng.','Tưởng niệm','Trang trọng'),
 (r'easter','Phục sinh','Mừng Chúa Giêsu phục sinh trong Kitô giáo; ngày thay đổi theo truyền thống và lịch phụng vụ.','Tôn giáo','Theo cộng đồng'),
 (r'pentecost|whit monday|whit sunday','Lễ Hiện Xuống','Kỷ niệm Chúa Thánh Thần hiện xuống trong truyền thống Kitô giáo.','Tôn giáo','Theo cộng đồng'),
 (r'ascension','Lễ Thăng Thiên','Kỷ niệm Chúa Giêsu lên trời trong Kitô giáo.','Tôn giáo','Theo cộng đồng'),
 (r'corpus christi','Lễ Mình và Máu Thánh Chúa','Tôn kính Bí tích Thánh Thể trong Công giáo.','Tôn giáo','Theo cộng đồng'),
 (r'all saints','Lễ Các Thánh','Tôn kính các thánh trong truyền thống Kitô giáo.','Tôn giáo','Theo cộng đồng'),
 (r'all souls|day of the dead','Tưởng nhớ người đã khuất','Dịp tưởng nhớ người đã qua đời, với nghi thức gia đình và tôn giáo tùy nơi.','Tưởng niệm','Trang trọng'),
 (r'assumption|immaculate conception|annunciation|virgin mary','Ngày lễ Đức Maria','Ngày lễ tôn kính Đức Maria trong truyền thống Kitô giáo; xem tên gốc để phân biệt từng lễ.','Tôn giáo','Theo cộng đồng'),
 (r'epiphany','Lễ Hiển Linh','Ngày lễ Kitô giáo về sự tỏ mình của Chúa Giêsu; tập tục khác nhau theo truyền thống.','Tôn giáo','Theo cộng đồng'),
 (r'vesak|buddha|buddhist|poya|makha|visakha|asarnha','Ngày lễ Phật giáo','Dịp thực hành tín ngưỡng Phật giáo; ý nghĩa cụ thể phụ thuộc ngày lễ và truyền thống địa phương.','Tôn giáo','Theo cộng đồng'),
 (r'diwali|deepavali','Diwali / Deepavali','Lễ hội ánh sáng, gắn với chiến thắng của ánh sáng trước bóng tối; ý nghĩa cụ thể khác nhau theo tôn giáo và vùng.','Lễ hội','Theo cộng đồng'),
 (r'holi','Holi','Lễ hội sắc màu đón xuân, gắn với niềm vui cộng đồng và chủ đề cái thiện chiến thắng cái ác.','Lễ hội','Vui tươi'),
 (r'dussehra|dashain|vijaya','Dussehra / Dashain','Dịp lễ Hindu thường gắn với chiến thắng của cái thiện trước cái ác và sum họp gia đình.','Tôn giáo','Theo cộng đồng'),
 (r'janmashtami|krishna','Ngày lễ Krishna','Ngày lễ trong truyền thống Hindu liên quan đến thần Krishna; xem tên gốc để xác định dịp cụ thể.','Tôn giáo','Theo cộng đồng'),
 (r'maha shiv|shivaratri','Maha Shivaratri','Đêm lễ tôn kính thần Shiva trong truyền thống Hindu.','Tôn giáo','Theo cộng đồng'),
 (r'rosh hashan','Rosh Hashanah','Năm mới Do Thái, gắn với suy ngẫm, cầu nguyện và khởi đầu mới.','Tôn giáo','Theo cộng đồng'),
 (r'yom kippur','Yom Kippur','Ngày chuộc tội trong Do Thái giáo, dành cho chay tịnh, sám hối và cầu nguyện.','Tôn giáo','Trang trọng'),
 (r'passover|pesach','Lễ Vượt Qua','Tưởng nhớ cuộc giải phóng người Israel khỏi cảnh nô lệ ở Ai Cập trong truyền thống Do Thái.','Tôn giáo','Theo cộng đồng'),
 (r'sukkot|shavuot|simchat|shemini','Ngày lễ Do Thái giáo','Dịp lễ trong lịch Do Thái; cần xem tên gốc và biên tập thêm ý nghĩa riêng của từng lễ.','Tôn giáo','Theo cộng đồng'),
 (r'nowruz|novruz|naur[yuz]|navruz','Nowruz','Đón năm mới vào thời điểm xuân phân trong nhiều cộng đồng ở Tây Á, Trung Á và khu vực lân cận.','Lễ hội','Vui tươi'),
 (r'carnival|carnaval|mardi gras|shrove','Carnival','Dịp hội hè với âm nhạc, hóa trang hoặc diễu hành; nhiều nơi tổ chức trước Mùa Chay Kitô giáo.','Lễ hội','Vui tươi'),
 (r'mid.autumn|chuseok','Lễ hội mùa thu','Dịp lễ mùa thu gắn với đoàn tụ và truyền thống cộng đồng; tập tục khác nhau theo quốc gia.','Lễ hội','Vui tươi'),
 (r'dragon boat|tuen ng','Lễ hội thuyền rồng','Lễ truyền thống gắn với đua thuyền và các tập tục văn hóa địa phương.','Lễ hội','Vui tươi'),
 (r'qingming|tomb.sweeping','Thanh minh','Dịp tảo mộ, tưởng nhớ tổ tiên và chăm sóc phần mộ gia đình.','Tưởng niệm','Trang trọng'),
 (r'independen','Ngày Độc lập','Kỷ niệm nền độc lập của quốc gia; bối cảnh và mốc lịch sử cần đối chiếu nguồn riêng của nước đó.','Quốc gia','Vui tươi'),
 (r'national day|national holiday','Quốc khánh / ngày lễ quốc gia','Dịp kỷ niệm cấp quốc gia; cần đối chiếu nguồn quốc gia để xác định sự kiện lịch sử cụ thể.','Quốc gia','Vui tươi'),
 (r'republic','Ngày Cộng hòa','Kỷ niệm thể chế hoặc một mốc lịch sử của nền cộng hòa tại quốc gia này.','Quốc gia','Trang trọng'),
 (r'constitution','Ngày Hiến pháp','Kỷ niệm hiến pháp hoặc một mốc hiến định của quốc gia.','Quốc gia','Trang trọng'),
 (r'labo[u]?r|workers','Ngày Lao động','Tôn vinh người lao động và những đóng góp của họ cho xã hội.','Xã hội','Vui tươi'),
 (r'women','Ngày Phụ nữ','Tôn vinh đóng góp của phụ nữ và thúc đẩy bình đẳng giới.','Xã hội','Vui tươi'),
 (r'children','Ngày Trẻ em','Tôn vinh trẻ em và nhấn mạnh quyền, sự chăm sóc và hạnh phúc của trẻ.','Xã hội','Vui tươi'),
 (r'mother','Ngày của Mẹ','Tôn vinh người mẹ và sự chăm sóc trong gia đình.','Xã hội','Vui tươi'),
 (r'father','Ngày của Cha','Tôn vinh người cha và vai trò chăm sóc trong gia đình.','Xã hội','Vui tươi'),
 (r'liberation|reunification','Ngày Giải phóng / Thống nhất','Kỷ niệm một mốc giải phóng hoặc thống nhất; cần trình bày theo bối cảnh lịch sử của quốc gia.','Quốc gia','Trang trọng'),
 (r'martyr|memorial|remembrance|mourning|genocide|holocaust|armistice|anzac','Ngày tưởng niệm','Tưởng nhớ người đã mất hoặc những hy sinh trong lịch sử; tránh hiệu ứng tiệc tùng và lời chúc vui vẻ.','Tưởng niệm','Trang trọng'),
 (r'veteran','Ngày Cựu chiến binh','Ghi nhận đóng góp và sự phục vụ của các cựu chiến binh.','Tưởng niệm','Trang trọng'),
 (r'thanksgiving','Lễ Tạ ơn','Dịp bày tỏ lòng biết ơn và sum họp, với lịch sử và tập tục riêng theo quốc gia.','Lễ hội','Vui tươi'),
 (r'boxing','Boxing Day','Ngày sau Giáng sinh trong một số quốc gia; gắn với tập tục tặng quà, sẻ chia hoặc nghỉ ngơi.','Lễ hội','Vui tươi'),
 (r'hung kings','Giỗ Tổ Hùng Vương','Tưởng nhớ các Vua Hùng và truyền thống dựng nước của người Việt.','Tưởng niệm','Trang trọng'),
 (r'culture|cultural','Ngày Văn hóa','Tôn vinh đời sống văn hóa và di sản của cộng đồng hoặc quốc gia.','Văn hóa','Vui tươi'),
]

def describe(name,country):
    for pat,title,meaning,kind,tone in RULES:
        if re.search(pat,name,re.I): return title,meaning,kind,tone,'Tóm lược theo nhóm; cần duyệt ý nghĩa riêng'
    return name,f'Sự kiện “{name}” tại {country}. Chưa có thuyết minh riêng đã kiểm chứng; cần bổ sung trước khi hiển thị cho người dùng.','Khác','Cần duyệt','Thiếu thuyết minh riêng'

RULES[:0]=[
 (r'maundy thursday','Thứ Năm Tuần Thánh','Tưởng nhớ Bữa Tiệc Ly của Chúa Giêsu trong truyền thống Kitô giáo.','Tôn giáo','Trang trọng'),
 (r'holy saturday','Thứ Bảy Tuần Thánh','Ngày suy niệm giữa Thứ Sáu Tuần Thánh và lễ Phục sinh trong Kitô giáo.','Tôn giáo','Trang trọng'),
 (r'ash wednesday|green monday','Khởi đầu Mùa Chay','Dịp mở đầu thời gian chay tịnh và suy ngẫm theo truyền thống Kitô giáo tương ứng.','Tôn giáo','Trang trọng'),
 (r'arafah','Ngày Arafah','Ngày quan trọng trong kỳ hành hương Hajj của người Hồi giáo, gắn với cầu nguyện và suy ngẫm.','Tôn giáo','Theo cộng đồng'),
 (r'laylat al.qadr','Laylat al-Qadr','Đêm thiêng liêng trong tháng Ramadan, gắn với việc mặc khải Kinh Quran trong truyền thống Hồi giáo.','Tôn giáo','Theo cộng đồng'),
 (r'emancipation','Ngày Giải phóng khỏi chế độ nô lệ','Tưởng nhớ việc chấm dứt chế độ nô lệ và tôn vinh tự do; mốc lịch sử khác nhau theo quốc gia.','Tưởng niệm','Trang trọng'),
 (r'victory|victory over','Ngày Chiến thắng','Kỷ niệm chiến thắng trong một biến cố lịch sử; cần xác định cuộc chiến và bối cảnh riêng của quốc gia.','Quốc gia','Trang trọng'),
 (r'armed forces|army day','Ngày Quân đội','Ghi nhận vai trò và lịch sử của lực lượng vũ trang quốc gia.','Quốc gia','Trang trọng'),
 (r'revolution','Ngày Cách mạng','Kỷ niệm một cuộc cách mạng hoặc bước ngoặt chính trị trong lịch sử quốc gia.','Quốc gia','Trang trọng'),
 (r'statehood','Ngày thành lập nhà nước','Kỷ niệm một mốc hình thành hoặc khôi phục nhà nước; cần đối chiếu lịch sử quốc gia.','Quốc gia','Trang trọng'),
 (r'unity','Ngày Đoàn kết','Tôn vinh tinh thần đoàn kết của quốc gia hoặc cộng đồng.','Quốc gia','Trang trọng'),
 (r'heroes','Ngày Anh hùng','Tưởng nhớ và ghi nhận những nhân vật có đóng góp hoặc hy sinh trong lịch sử quốc gia.','Tưởng niệm','Trang trọng'),
 (r'youth','Ngày Thanh niên','Ghi nhận vai trò, tiếng nói và đóng góp của thế hệ trẻ.','Xã hội','Vui tươi'),
 (r'family','Ngày Gia đình','Tôn vinh tình cảm, sự chăm sóc và gắn kết trong gia đình.','Xã hội','Vui tươi'),
 (r'worker.s|may day','Ngày Lao động / ngày hội tháng Năm','Thường tôn vinh người lao động hoặc truyền thống đầu tháng Năm; cần xác định ý nghĩa theo quốc gia.','Xã hội','Cần duyệt'),
 (r'king.*birthday|birth.*king|queen.*birthday','Sinh nhật quân vương','Dịp mừng sinh nhật chính thức hoặc thực tế của quân vương; ngày tổ chức có thể khác ngày sinh.','Quốc gia','Trang trọng'),
 (r'president.s day','Ngày Tổng thống','Ngày kỷ niệm liên quan đến chức vụ tổng thống; nhân vật và truyền thống cụ thể tùy quốc gia.','Quốc gia','Trang trọng'),
 (r'africa day','Ngày châu Phi','Kỷ niệm việc thành lập Tổ chức Thống nhất châu Phi năm 1963, tôn vinh đoàn kết châu Phi.','Quốc tế','Trang trọng'),
 (r'europe day','Ngày châu Âu','Tôn vinh hòa bình và hợp tác châu Âu; có các ngày kỷ niệm khác nhau tùy thể chế.','Quốc tế','Trang trọng'),
 (r'united nations','Ngày Liên Hợp Quốc','Kỷ niệm Hiến chương Liên Hợp Quốc có hiệu lực ngày 24/10/1945.','Quốc tế','Trang trọng'),
 (r'flag day','Ngày Quốc kỳ','Tôn vinh quốc kỳ và những giá trị hoặc lịch sử mà quốc kỳ biểu trưng.','Quốc gia','Trang trọng'),
 (r'freedom day','Ngày Tự do','Kỷ niệm một dấu mốc về tự do trong lịch sử quốc gia; cần bổ sung bối cảnh cụ thể.','Quốc gia','Trang trọng'),
 (r'midsummer','Lễ giữa mùa hè','Dịp sinh hoạt cộng đồng giữa mùa hè với tập tục dân gian khác nhau theo quốc gia.','Lễ hội','Vui tươi'),
 (r'pchum ben','Pchum Ben','Lễ Phật giáo Khmer tưởng nhớ tổ tiên và làm công đức cho người đã khuất.','Tưởng niệm','Trang trọng'),
 (r'water festival','Lễ hội nước','Dịp lễ gắn với nước và truyền thống cộng đồng; ý nghĩa cụ thể khác nhau giữa các quốc gia.','Lễ hội','Cần duyệt'),
 (r'songkran','Songkran','Tết truyền thống gắn với đoàn tụ, nghi thức Phật giáo và tập tục với nước.','Lễ hội','Vui tươi'),
 (r'losar','Losar','Tết truyền thống theo lịch Tây Tạng trong các cộng đồng liên quan.','Lễ hội','Theo cộng đồng'),
 (r'ram navami','Rama Navami','Lễ kỷ niệm ngày sinh của thần Rama trong truyền thống Hindu.','Tôn giáo','Theo cộng đồng'),
 (r'vodoun','Lễ hội Vodun','Dịp tôn vinh tín ngưỡng Vodun và di sản của các cộng đồng thực hành.','Tôn giáo','Theo cộng đồng'),
 (r'farmer|peasant','Ngày Nông dân','Tôn vinh lao động nông nghiệp và đóng góp của nông dân cho xã hội.','Xã hội','Vui tươi'),
 (r'reformation','Ngày Cải cách','Kỷ niệm phong trào Cải cách trong lịch sử Kitô giáo, đặc biệt trong các truyền thống Tin Lành.','Tôn giáo','Theo cộng đồng'),
 (r'gospel day','Ngày Tin Mừng','Dịp kỷ niệm việc truyền bá Kitô giáo trong lịch sử địa phương.','Tôn giáo','Theo cộng đồng'),
 (r'saint |saints ','Ngày kính thánh','Ngày kính một hoặc nhiều vị thánh trong Kitô giáo; tên gốc cho biết nhân vật được tôn kính.','Tôn giáo','Theo cộng đồng'),
 (r'additional day off|day off|bank holiday','Ngày nghỉ theo lịch','Ngày nghỉ hoặc điều chỉnh hành chính trong lịch; không mặc định đây là một lễ hội hay ngày kỷ niệm riêng.','Nghỉ bù / điều chỉnh','Thông báo lịch'),
]

# A curated supplement: cultural festivals are not automatically public holidays.
# Variable dates are deliberately blank; references are provided for editorial checking.
FESTIVALS=[
 ('VN','Tết Trung thu','09-15 âm lịch','Trẻ em vui hội trăng rằm, rước đèn và thưởng thức bánh Trung thu.','Mid-Autumn_Festival',None),
 ('VN','Lễ hội Chùa Hương','Mùa xuân âm lịch; lịch tổ chức theo năm','Hành hương và sinh hoạt văn hóa, tín ngưỡng tại quần thể Chùa Hương.','Hương_Pagoda',None),
 ('TH','Songkran','04-13 đến 04-15','Tết truyền thống Thái Lan; gắn với làm mới bản thân, kính trọng người lớn và nghi thức với nước.','Songkran_(Thailand)',(4,13)),
 ('TH','Loy Krathong','Rằm tháng 12 âm lịch Thái','Thả đèn nổi krathong như một nghi thức gắn với nước và việc buông bỏ điều không may.','Loy_Krathong',None),
 ('LA','Pi Mai','Khoảng giữa tháng 4; xác minh lịch từng năm','Tết Lào, với nghi thức Phật giáo, té nước và sinh hoạt cộng đồng.','Lao_New_Year',None),
 ('KH','Choul Chnam Thmey','Khoảng giữa tháng 4; xác minh lịch từng năm','Tết Khmer, dịp đoàn tụ, làm công đức và trò chơi truyền thống.','Cambodian_New_Year',None),
 ('MM','Thingyan','Khoảng giữa tháng 4; xác minh lịch từng năm','Lễ hội nước đón năm mới Myanmar và các sinh hoạt làm phước.','Thingyan',None),
 ('CN','Lễ hội đèn lồng','01-15 âm lịch Trung Quốc','Kết thúc chu kỳ vui Tết với đèn lồng, sum họp và các món ăn truyền thống.','Lantern_Festival',None),
 ('JP','Tanabata','07-07; một số nơi tổ chức vào tháng 8','Lễ hội các vì sao với điều ước viết trên dải giấy trang trí cành tre.','Tanabata',(7,7)),
 ('JP','Obon','Thường tháng 7 hoặc tháng 8 tùy địa phương','Dịp tưởng nhớ tổ tiên, trở về quê hương và múa Bon Odori.','Bon_Festival',None),
 ('KR','Chuseok','08-15 âm lịch Hàn Quốc','Dịp đoàn tụ mùa thu, tưởng nhớ tổ tiên và chia sẻ thành quả mùa màng.','Chuseok',None),
 ('MN','Naadam','07-11 đến 07-13; kiểm tra chương trình địa phương','Lễ hội nổi bật với đấu vật, đua ngựa và bắn cung, tôn vinh truyền thống Mông Cổ.','Naadam',(7,11)),
 ('IN','Holi','Lịch Hindu; thay đổi theo năm và vùng','Lễ hội sắc màu gắn với mùa xuân và niềm vui cộng đồng.','Holi',None),
 ('IN','Diwali','Lịch Hindu; thay đổi theo năm','Lễ hội ánh sáng; ý nghĩa thay đổi theo tôn giáo và vùng.','Diwali',None),
 ('NP','Dashain','Lịch Hindu; thay đổi theo năm','Dịp lễ quan trọng với đoàn tụ gia đình, lời chúc phúc và truyền thống Hindu.','Dashain',None),
 ('BD','Pohela Boishakh','04-14 tại Bangladesh','Đón năm mới Bengali với sinh hoạt văn hóa cộng đồng.','Pohela_Boishakh',(4,14)),
 ('LK','Esala Perahera','Lịch Phật giáo; lịch Kandy công bố mỗi năm','Lễ rước tôn giáo tại Kandy gắn với truyền thống tôn kính xá lợi răng Phật.','Kandy_Esala_Perahera',None),
 ('BT','Paro Tshechu','Lịch Bhutan; công bố mỗi năm','Lễ hội Phật giáo tại Paro nổi bật với múa mặt nạ và sinh hoạt tín ngưỡng.','Paro_Tshechu',None),
 ('ID','Nyepi','Lịch Saka Bali; thay đổi theo năm','Ngày tĩnh lặng của người Hindu Bali, dành cho chiêm nghiệm và khởi đầu năm mới.','Nyepi',None),
 ('MY','Thaipusam','Lịch Tamil; thay đổi theo năm','Lễ Hindu tôn kính thần Murugan, với hành hương và những thực hành sùng kính.','Thaipusam',None),
 ('SG','Thaipusam','Lịch Tamil; thay đổi theo năm','Lễ tôn kính thần Murugan trong cộng đồng Hindu Tamil tại Singapore.','Thaipusam',None),
 ('PH','Sinulog','Chủ nhật thứ ba tháng 1; xác nhận chương trình','Lễ hội tại Cebu tôn kính Santo Niño, kết hợp tín ngưỡng và diễu hành văn hóa.','Sinulog',None),
 ('TL','Lễ hội Baucau','Lịch địa phương; cần xác minh','Cần bổ sung tên lễ hội và chương trình được cơ quan địa phương xác nhận.','Culture_of_East_Timor',None),
 ('IR','Nowruz','Xuân phân; xác nhận ngày địa phương','Năm mới Ba Tư, gắn với mùa xuân, thăm hỏi và làm mới cuộc sống.','Nowruz',None),
 ('AZ','Novruz','Khoảng xuân phân; xác nhận lịch quốc gia','Đón xuân và năm mới theo truyền thống cộng đồng.','Novruz_in_Azerbaijan',None),
 ('TR','Hıdırellez','05-06','Lễ hội mùa xuân gắn với sự tái sinh của thiên nhiên và các tập tục cầu may.','Hıdırellez',(5,6)),
 ('ES','La Tomatina','Thứ tư cuối tháng 8; lịch Buñol','Lễ hội ném cà chua mang tính vui chơi cộng đồng tại Buñol.','La_Tomatina',None),
 ('ES','Las Fallas','Cao điểm 03-15 đến 03-19; lịch Valencia','Lễ hội Valencia với các tác phẩm tạo hình và nghi thức đốt, gắn với Thánh Giuse.','Fallas',(3,19)),
 ('DE','Oktoberfest','Tháng 9–10; lịch Munich công bố từng năm','Lễ hội dân gian tại Munich, nổi bật với văn hóa Bavaria, ẩm thực và âm nhạc.','Oktoberfest',None),
 ('FR','Fête de la Musique','06-21','Ngày hội âm nhạc với biểu diễn và tham gia cộng đồng.','Fête_de_la_Musique',(6,21)),
 ('IT','Carnival of Venice','Trước Mùa Chay; lịch Venice từng năm','Lễ hội hóa trang nổi tiếng với mặt nạ và các sinh hoạt nghệ thuật tại Venice.','Carnival_of_Venice',None),
 ('PT','Santo António tại Lisbon','06-13; hoạt động lân cận tùy năm','Lễ hội địa phương tôn kính Thánh Antôn với âm nhạc và sinh hoạt khu phố.','Anthony_of_Padua',(6,13)),
 ('IE','Saint Patrick’s Day','03-17','Ngày lễ gắn với Thánh Patrick và di sản văn hóa Ireland.','Saint_Patrick%27s_Day',(3,17)),
 ('GB','Notting Hill Carnival','Cuối tuần kỳ nghỉ ngân hàng tháng 8; lịch London','Lễ hội đường phố tôn vinh văn hóa Caribe tại London.','Notting_Hill_Carnival',None),
 ('SE','Midsummer','Cuối tháng 6; phân biệt đêm lễ và ngày nghỉ','Lễ hội giữa mùa hè với sinh hoạt ngoài trời và truyền thống cộng đồng.','Midsummer',None),
 ('FI','Juhannus','Cuối tháng 6; lịch từng năm','Lễ giữa mùa hè ở Phần Lan với sinh hoạt gia đình và truyền thống địa phương.','Midsummer',None),
 ('NO','Ngày Hiến pháp','05-17','Kỷ niệm Hiến pháp Na Uy với diễu hành trẻ em và sinh hoạt cộng đồng.','Constitution_Day_(Norway)',(5,17)),
 ('DK','Sankt Hans Aften','06-23','Đêm lễ giữa mùa hè với lửa trại và sinh hoạt cộng đồng.','Saint_John%27s_Eve',(6,23)),
 ('PL','Wianki','Gần hạ chí; lịch từng thành phố','Lễ hội mùa hè gắn với vòng hoa, âm nhạc và tập tục dân gian.','Wianki',None),
 ('UA','Ivana Kupala','Ngày tùy truyền thống và lịch tôn giáo','Lễ hội dân gian mùa hè với biểu tượng nước, lửa và thiên nhiên.','Kupala_Night',None),
 ('GR','Apokries','Trước Mùa Chay Chính thống; thay đổi theo năm','Mùa hội hóa trang và sinh hoạt cộng đồng trước thời gian chay tịnh.','Carnival_in_Greece',None),
 ('BE','Carnival of Binche','Trước Mùa Chay; thay đổi theo năm','Lễ hội hóa trang truyền thống tại Binche, nổi bật với nhân vật Gilles.','Carnival_of_Binche',None),
 ('NL','King’s Day','04-27; chuyển 04-26 nếu là Chủ nhật','Ngày hội mừng sinh nhật nhà vua với sắc cam và hoạt động cộng đồng.','Koningsdag',None),
 ('CH','Basel Fasnacht','Sau Thứ Tư Lễ Tro; lịch Basel','Lễ hội hóa trang truyền thống tại Basel với đèn lồng, âm nhạc và diễu hành.','Carnival_of_Basel',None),
 ('AT','Vienna Ball Season','Mùa đông; tùy từng vũ hội','Mùa vũ hội gắn với truyền thống khiêu vũ và đời sống văn hóa Vienna.','Vienna_Opera_Ball',None),
 ('BR','Carnival','Trước Mùa Chay; lịch từng thành phố','Lễ hội với samba, hóa trang và diễu hành; chương trình khác nhau theo địa phương.','Brazilian_Carnival',None),
 ('PE','Inti Raymi','06-24 tại Cusco','Lễ hội tôn vinh Mặt Trời, gắn với di sản Inca tại Cusco.','Inti_Raymi',(6,24)),
 ('BO','Carnival of Oruro','Trước Mùa Chay; lịch từng năm','Lễ hội kết hợp truyền thống Andean và Công giáo, nổi bật với các điệu múa.','Carnival_of_Oruro',None),
 ('CO','Carnival of Barranquilla','Trước Mùa Chay; lịch từng năm','Lễ hội âm nhạc, múa và hóa trang thể hiện sự đa dạng văn hóa vùng Caribe Colombia.','Barranquilla%27s_Carnival',None),
 ('AR','Vendimia','Mùa thu hoạch nho; lịch Mendoza','Lễ hội thu hoạch nho, tôn vinh lao động và văn hóa vùng trồng nho Mendoza.','Fiesta_Nacional_de_la_Vendimia',None),
 ('CL','Fiestas Patrias','09-18 và 09-19','Dịp lễ quốc gia với âm nhạc, múa cueca, ẩm thực và sum họp.','Fiestas_Patrias_(Chile)',(9,18)),
 ('EC','Inti Raymi','Quanh hạ chí; lịch từng cộng đồng','Lễ hội Mặt Trời trong các cộng đồng Andean, gắn với mùa màng và bản sắc bản địa.','Inti_Raymi',None),
 ('UY','Carnival','Mùa hè; lịch Montevideo từng năm','Mùa lễ hội với candombe, murga và biểu diễn cộng đồng.','Uruguayan_Carnival',None),
 ('MX','Día de Muertos','11-01 đến 11-02','Tưởng nhớ người đã khuất qua bàn thờ, hoa và sinh hoạt gia đình; giữ sắc thái tôn trọng.','Day_of_the_Dead',(11,2)),
 ('US','Mardi Gras tại New Orleans','Ngày trước Thứ Tư Lễ Tro; thay đổi theo năm','Lễ hội diễu hành, hóa trang và âm nhạc tại New Orleans.','Mardi_Gras_in_New_Orleans',None),
 ('CA','Québec Winter Carnival','Mùa đông; lịch Québec công bố từng năm','Lễ hội mùa đông với hoạt động ngoài trời và biểu tượng văn hóa Québec.','Quebec_Winter_Carnival',None),
 ('TT','Trinidad and Tobago Carnival','Trước Mùa Chay; thay đổi theo năm','Lễ hội hóa trang với soca, calypso, steelpan và diễu hành đường phố.','Trinidad_and_Tobago_Carnival',None),
 ('JM','Reggae Sumfest','Thường tháng 7; lịch ban tổ chức','Sự kiện âm nhạc tôn vinh reggae và các dòng nhạc Jamaica.','Reggae_Sumfest',None),
 ('BB','Crop Over','Mùa hè; lịch ban tổ chức từng năm','Lễ hội bắt nguồn từ mùa thu hoạch mía, với âm nhạc và diễu hành.','Crop_Over',None),
 ('BS','Junkanoo','12-26 và 01-01; xác minh lịch diễu hành','Lễ hội đường phố với trang phục, âm nhạc và diễu hành của cộng đồng Bahamas.','Junkanoo',None),
 ('GT','Giant Kite Festival','11-01 tại Sumpango và Santiago Sacatepéquez','Thả diều khổng lồ gắn với tưởng nhớ tổ tiên và truyền thống cộng đồng.','Giant_kite_festival',(11,1)),
 ('ET','Timkat','Theo lịch Ethiopia; xác nhận ngày dương lịch','Lễ Hiển Linh của Chính thống Ethiopia, tưởng nhớ phép rửa của Chúa Giêsu.','Timkat',None),
 ('NG','Osun-Osogbo Festival','Thường tháng 8; lịch địa phương','Lễ hội Yoruba gắn với thần Osun, rừng thiêng và bản sắc cộng đồng Osogbo.','Osun-Osogbo',None),
 ('GH','Homowo','Mùa thu hoạch; lịch từng cộng đồng Ga','Lễ hội của người Ga, tưởng nhớ việc vượt qua nạn đói và tạ ơn mùa màng.','Homowo',None),
 ('SN','Grand Magal of Touba','18 Safar theo lịch Hồi giáo','Cuộc hành hương của cộng đồng Mouride tưởng nhớ cuộc lưu đày của Ahmadou Bamba.','Grand_Magal_of_Touba',None),
 ('MA','Moussem of Tan-Tan','Lịch ban tổ chức từng năm','Cuộc gặp gỡ văn hóa cộng đồng du mục vùng Sahara, với âm nhạc và truyền thống truyền khẩu.','Tan-Tan_Moussem',None),
 ('TN','International Festival of the Sahara','Lịch Douz công bố từng năm','Lễ hội tại Douz tôn vinh văn hóa và di sản vùng Sahara.','International_Festival_of_the_Sahara',None),
 ('EG','Sham el-Nessim','Thứ hai sau Phục sinh Coptic','Lễ hội mùa xuân với sinh hoạt ngoài trời và ẩm thực truyền thống Ai Cập.','Sham_Ennessim',None),
 ('ZA','Heritage Day','09-24','Tôn vinh sự đa dạng di sản và bản sắc văn hóa của Nam Phi.','Heritage_Day_(South_Africa)',(9,24)),
 ('SZ','Umhlanga','Cuối tháng 8 hoặc đầu tháng 9; công bố hằng năm','Nghi lễ múa sậy gắn với truyền thống hoàng gia và cộng đồng Eswatini.','Umhlanga_(ceremony)',None),
 ('MG','Famadihana','Theo gia đình và địa phương; không có ngày chung','Nghi thức gia đình tưởng nhớ tổ tiên của một số cộng đồng Madagascar; không phải lễ toàn dân.','Famadihana',None),
 ('MU','Maha Shivaratri tại Ganga Talao','Lịch Hindu; thay đổi theo năm','Hành hương và cầu nguyện tôn kính thần Shiva tại Ganga Talao.','Ganga_Talao',None),
 ('TZ','Sauti za Busara','Thường tháng 2; lịch Zanzibar','Lễ hội âm nhạc tập trung vào nghệ sĩ và văn hóa châu Phi.','Sauti_za_Busara',None),
 ('BF','FESPACO','Hai năm một lần; lịch ban tổ chức','Liên hoan phim tại Ouagadougou tôn vinh điện ảnh châu Phi; không phải sự kiện hằng năm.','FESPACO',None),
 ('AU','NAIDOC Week','Thường tháng 7; lịch công bố từng năm','Tôn vinh lịch sử, văn hóa và thành tựu của các dân tộc Aboriginal và Torres Strait Islander.','NAIDOC_Week',None),
 ('NZ','Matariki','Lịch chính thức công bố theo năm','Năm mới Māori gắn với cụm sao Matariki, tưởng nhớ, sum họp và hướng tới tương lai.','Matariki',None),
 ('PG','Goroka Show','Thường tháng 9; lịch ban tổ chức','Sự kiện văn hóa tại Goroka với múa, âm nhạc và trang phục của nhiều cộng đồng.','Goroka_Show',None),
 ('FJ','Hibiscus Festival','Lịch ban tổ chức từng năm','Lễ hội cộng đồng Fiji với hoạt động văn hóa, giải trí và gây quỹ.','Hibiscus_Festival',None),
 ('WS','Teuila Festival','Thường tháng 9; lịch chính thức từng năm','Lễ hội văn hóa Samoa với múa, âm nhạc, thủ công và sinh hoạt cộng đồng.','Teuila_Festival',None),
 ('TO','Heilala Festival','Thường tháng 7; lịch chính thức từng năm','Lễ hội văn hóa Tonga gắn với biểu diễn, cộng đồng và truyền thống địa phương.','Heilala_Festival',None),
 ('VU','Naghol','Mùa nghi lễ tại Pentecost; lịch cộng đồng','Nghi lễ land diving tại đảo Pentecost, gắn với truyền thống và mùa màng; không phải lễ toàn quốc.','Land_diving',None),
 ('SB','Wagosia','Theo lịch cộng đồng Aorigi','Nghi lễ truyền thống của cộng đồng Aorigi; cần làm việc với nguồn địa phương trước khi giới thiệu.','Culture_of_the_Solomon_Islands',None),
]
# Remove provisional entries whose event identity has not been established.
FESTIVALS=[f for f in FESTIVALS if f[1] not in ('Lễ hội Baucau','Wagosia')]

H=['event_id','Châu lục','ISO2','Quốc gia','Ngày','Năm','Tên sự kiện (nguồn)','Nhãn tiếng Việt (nhóm)','Loại','Ý nghĩa tiếng Việt','Sắc thái','Ngày nghỉ bù','Ngày ước tính','Phạm vi','Cách xác định ngày','Trạng thái nội dung','Đã duyệt nguồn chính thức','auto_celebrate','Nguồn dữ liệu','Nguồn tham chiếu']
FH=['festival_id','Châu lục','ISO2','Quốc gia','Lễ hội','Ý nghĩa tiếng Việt','Thời điểm / quy tắc','Ngày tham khảo 2026','Ngày tham khảo 2027','Phạm vi','Ngày nghỉ công cộng?','Trạng thái','Nguồn tham khảo','auto_celebrate']
rows=[]; festival_rows=[]; inventory=[]; sources=[]; errors=[]
for c in sorted(countries,key=lambda c:(continent(c),c['cca2'])):
    iso=c['cca2']; country=vi.territories.get(iso,c['name']['common']); cont=CONT[continent(c)]
    try:
        h=holidays.country_holidays(iso,years=YEARS,language='en_US',observed=True)
        raw=holidays.country_holidays(iso,years=YEARS,language='en_US',observed=False)
        mod=inspect.getmodule(type(h)); module=Path(mod.__file__).stem
        source=f'https://github.com/vacanza/holidays/blob/v{holidays.__version__}/holidays/countries/{module}.py'
        docs='\n'.join((cls.__doc__ or '') for cls in type(h).__mro__ if cls.__module__==mod.__name__)
        refs=list(dict.fromkeys(re.findall(r'https?://[^\s)\]>]+',docs)))
        sources.append([iso,country,source,' | '.join(refs),holidays.__version__,'2026-11-07','Chưa kiểm chứng trực tiếp văn bản gốc'])
        start=len(rows)
        for dt,joined in sorted(h.items()):
            if dt.year not in YEARS: continue
            for name in h.get_list(dt):
                title,meaning,kind,tone,state=describe(name,country)
                obs=(name not in raw.get_list(dt)) or bool(re.search(r'observed|substitut|in lieu|day off|in-lieu',name,re.I))
                estimated=bool(re.search('estimated|tentative',name,re.I))
                if obs: kind='Nghỉ bù / điều chỉnh'; tone='Thông báo lịch'
                eid=hashlib.sha1(f'{iso}|{dt}|{name}'.encode()).hexdigest()[:16]
                rows.append([eid,cont,iso,country,dt,dt.year,name,title,kind,meaning,tone,obs,estimated,'Cấp quốc gia theo danh mục PUBLIC của nguồn; không bao gồm đầy đủ lễ vùng',f'Tính riêng cho năm {dt.year} bằng holidays {holidays.__version__}; không suy ra quy tắc lặp từ hai năm',state,False,False,source,refs[0] if refs else ''])
        for iso2,title,rule,meaning,wiki,fixed in FESTIVALS:
            if iso2!=iso: continue
            ds=[datetime(y,*fixed).date() if fixed else None for y in YEARS]
            festival_rows.append([hashlib.sha1(f'{iso}|{title}'.encode()).hexdigest()[:16],cont,iso,country,title,meaning,rule,*ds,'Văn hóa / cộng đồng / địa phương; xem mô tả','Không suy ra; đối chiếu sheet Ngay_le','Bản biên tập tham khảo; cần xác minh lịch và phạm vi',f'https://en.wikipedia.org/wiki/{wiki}',False])
        count=len(rows)-start
        inventory.append([cont,iso,country,c['name']['common'],count,len([x for x in festival_rows if x[2]==iso]),len([x for x in rows[start:] if x[8] in ('Lễ hội','Tôn giáo')]),'Có dữ liệu' if count else 'Nguồn không có ngày PUBLIC cho 2026–2027',', '.join(c.get('timezones',[])) if isinstance(c.get('timezones'),list) else 'Lấy IANA timezone từ hồ sơ người dùng / địa phương','Chưa duyệt để tự động phát'])
    except Exception as e: errors.append([iso,str(e)])

GUIDE=[
 ['Mục','Nội dung'],
 ['Mục đích','Dữ liệu nền cho HappyRoom mở rộng từ sinh nhật sang ngày lễ và sự kiện theo quốc gia. Đây là bản tham khảo có cờ rà soát, chưa phải lịch chính thức đã duyệt.'],
 ['Phạm vi quốc gia','195 quốc gia: 193 thành viên Liên Hợp Quốc + Tòa Thánh/Vatican (VA) + Nhà nước Palestine (PS). Không gồm toàn bộ lãnh thổ phụ thuộc và các thực thể khác.'],
 ['Châu lục','6 nhóm: Á, Âu, Phi, Bắc Mỹ (gồm Trung Mỹ và Caribe), Nam Mỹ, Đại Dương. Không có quốc gia ở Nam Cực. Phân vùng theo mledoze/countries; nước xuyên lục địa chỉ xuất hiện trong một nhóm để tránh lặp.'],
 ['Khoảng thời gian','Ngày cụ thể trong 2026 và 2027. Không mặc định các ngày giống nhau giữa hai năm là ngày cố định.'],
 ['Nguồn ngày lễ',f'Python holidays phiên bản {holidays.__version__}, danh mục PUBLIC mặc định, observed=True; nguồn mã theo quốc gia và tài liệu tham chiếu được ghi trong Nguon.'],
 ['Giới hạn','Bao phủ đủ danh mục 195 quốc gia không đồng nghĩa đầy đủ mọi lễ hội. Không bao quát toàn bộ lễ địa phương, lễ của cộng đồng thiểu số, lễ mới công bố, nghỉ bù đột xuất hoặc sự kiện thương mại.'],
 ['Nguồn lễ hội','Sheet Le_hoi_bo_sung là danh mục chọn lọc với mô tả biên tập và link tham khảo; nguồn và lịch tổ chức chưa được kiểm chứng độc lập. Ngày trống nghĩa là chưa xác định, không phải không tổ chức.'],
 ['Ý nghĩa','Mô tả tiếng Việt được biên tập theo nhóm ý nghĩa từ tên sự kiện; không phải bản dịch nguyên văn hay lịch sử riêng đã kiểm chứng. Dòng thiếu thuyết minh được gắn trạng thái riêng.'],
 ['Lễ tôn giáo','Nằm trong Ngay_le nếu nguồn coi là ngày PUBLIC. Có thể lọc Loại = Tôn giáo hoặc Lễ hội. Sheet Le_hoi_bo_sung bổ sung lễ hội văn hóa ngoài ngày nghỉ công cộng.'],
 ['Ngày nghỉ bù','So sánh lịch observed=True với observed=False kết hợp nhãn nguồn. Đây là phân loại tự động, cần duyệt; không nên coi ngày nghỉ bù là ngày kỷ niệm gốc.'],
 ['Ngày ước tính','Cờ dựa trên nhãn estimated/tentative của thư viện; FALSE không có nghĩa đã được cơ quan địa phương xác nhận. Ngày Hồi giáo có thể đổi theo quan sát trăng.'],
 ['An toàn nội dung','Các dịp tưởng niệm, quốc tang hoặc chay tịnh cần nội dung trang trọng; không tự động dùng pháo giấy, lời chúc ăn mừng hay thông báo vui nhộn.'],
 ['Tự động hóa','auto_celebrate = FALSE và Đã duyệt nguồn chính thức = FALSE cho toàn bộ bản nháp. Sau khi duyệt, chọn riêng hiển thị thông tin / lời chúc / tưởng niệm, không bật cùng một hiệu ứng cho mọi loại sự kiện.'],
 ['Múi giờ','Lưu IANA timezone của người dùng / địa phương. Một nước có thể nhiều múi giờ; không áp dụng một UTC offset cho toàn quốc. So sánh ngày theo timezone trước khi gửi.'],
 ['Chống trùng','event_id phân biệt từng lần xuất hiện theo quốc gia + ngày + tên. Dùng thêm khóa người dùng + event_id để gửi một lần. Một ngày có thể có nhiều sự kiện.'],
 ['Lặp hằng năm','event_id không phải mã chuỗi sự kiện vĩnh viễn. Nếu cần tái diễn, tạo series_id và quy tắc riêng sau khi duyệt; cập nhật dữ liệu cho năm mới thay vì sao chép ngày.'],
 ['Kiểm chứng trước khi dùng','Đối chiếu nguồn chính phủ / cơ quan tổ chức; xác minh ngày thực tế và nghỉ bù, phạm vi địa phương, ngôn ngữ, ý nghĩa, bản quyền và lựa chọn nhận thông báo của người dùng.'],
 ['Ngày tổng hợp','2026-11-07. Phiên bản thư viện được cố định trong nguồn đi kèm để có thể tái tạo.'],
 ['Định dạng','Ngày là ô ngày Excel (yyyy-mm-dd), ISO2 là mã quốc gia, Boolean là TRUE/FALSE; ô trống là chưa có dữ liệu. Mỗi file có bộ lọc, dòng tiêu đề cố định và danh mục nguồn.'],
 ['Cập nhật','Rà soát hằng năm và khi có thông báo mới từ chính quyền. Danh mục PUBLIC của thư viện không thay thế văn bản pháp lý về ngày nghỉ.'],
]

def sheet(wb,name,headers,data):
    ws=wb.create_sheet(name); ws.append(headers)
    for row in data: ws.append(row)
    ws.freeze_panes='A2'; ws.auto_filter.ref=ws.dimensions
    ws.sheet_view.showGridLines=False
    for cell in ws[1]: cell.fill=PatternFill('solid',fgColor='143B50'); cell.font=Font(color='FFFFFF',bold=True); cell.alignment=Alignment(wrap_text=True,vertical='top')
    ws.row_dimensions[1].height=34
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            if isinstance(cell.value,(datetime,)) or hasattr(cell.value,'year') and hasattr(cell.value,'month'): cell.number_format='yyyy-mm-dd'
            cell.alignment=Alignment(vertical='top',wrap_text=True)
        ws.row_dimensions[row[0].row].height=44
    for col in ws.columns:
        samples=[str(c.value or '') for c in list(col)[:120]]
        width=min(64,max(13,max(map(len,samples))+2))
        ws.column_dimensions[col[0].column_letter].width=width
    if data:
        tab=Table(displayName='T_'+name,ref=ws.dimensions); tab.tableStyleInfo=TableStyleInfo(name='TableStyleMedium2',showRowStripes=True); ws.add_table(tab)
    return ws

def book(path,isos):
    wb=Workbook(); wb.remove(wb.active)
    sheet(wb,'Huong_dan',GUIDE[0],GUIDE[1:])
    sheet(wb,'Quoc_gia',['Châu lục','ISO2','Quốc gia','Tên tiếng Anh','Số bản ghi ngày lễ','Lễ hội bổ sung','Bản ghi tôn giáo/lễ hội trong lịch','Bao phủ ngày lễ','Múi giờ','Trạng thái'],[r for r in inventory if r[1] in isos])
    sheet(wb,'Ngay_le',H,[r for r in rows if r[2] in isos])
    sheet(wb,'Le_hoi_bo_sung',FH,[r for r in festival_rows if r[2] in isos])
    sheet(wb,'Nguon',['ISO2','Quốc gia','Nguồn ngày lễ','Tài liệu nguồn liệt kê (chưa kiểm chứng trực tiếp)','Phiên bản','Ngày tổng hợp','Trạng thái'],[r for r in sources if r[0] in isos]+[['ALL','Phân loại quốc gia','https://github.com/mledoze/countries/blob/master/countries.json','', '', '2026-11-07','Snapshot JSON đi kèm']])
    wb.properties.title='HappyRoom — Ngày lễ và lễ hội 2026–2027'; wb.properties.creator='HappyRoom research draft'
    wb.save(path)

if errors: raise RuntimeError(errors)
assert len(inventory)==195
all_iso={c['cca2'] for c in countries}
book(ROOT/'HappyRoom_195_quoc_gia_2026_2027.xlsx',all_iso)
for cont in CONT:
    folder=ROOT/cont; folder.mkdir(exist_ok=True)
    members=[c for c in countries if continent(c)==cont]
    book(folder/f'{cont}_2026_2027.xlsx',{c['cca2'] for c in members})
    for c in members: book(folder/f"{c['cca2']}_{slug(c['name']['common'])}.xlsx",{c['cca2']})
    print(cont,len(members),flush=True)

for filename,header,data in [('events.csv',H,rows),('festivals.csv',FH,festival_rows),('countries.csv',['continent','iso2','country_vi','country_en','event_count','festival_count','religious_festival_event_count','coverage','timezone_note','status'],inventory)]:
    with (ROOT/filename).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f); w.writerow(header); w.writerows(data)
(ROOT/'README_vi.txt').write_text('\n\n'.join(f'{a}: {b}' for a,b in GUIDE[1:]),encoding='utf-8')
(ROOT/'countries_source_snapshot.json').write_bytes(Path(args.countries_source).read_bytes())
(ROOT/'requirements.txt').write_text(f'holidays=={holidays.__version__}\nopenpyxl==3.1.5\nBabel==2.18.0\n',encoding='utf-8')
(ROOT/'build_holidays.py').write_bytes(Path(__file__).read_bytes())

stats={'countries':len(inventory),'continents':len(CONT),'years':YEARS,'holiday_occurrences':len(rows),'supplemental_festivals':len(festival_rows),'missing_specific_meaning':sum(r[15]=='Thiếu thuyết minh riêng' for r in rows),'estimated_dates':sum(r[12] for r in rows),'countries_without_public_dates':[r[1] for r in inventory if r[4]==0],'xlsx_files':len(list(ROOT.rglob('*.xlsx'))),'errors':errors}
# Reopen every generated workbook and validate key fields and row counts.
for path in ROOT.rglob('*.xlsx'):
    wb=load_workbook(path,read_only=True,data_only=True)
    assert wb.sheetnames==['Huong_dan','Quoc_gia','Ngay_le','Le_hoi_bo_sung','Nguon'],path
    assert wb['Quoc_gia'].max_row>=2,path
    wb.close()
assert len({r[0] for r in rows})==len(rows)
assert all(r[4].year in YEARS and not r[16] and not r[17] for r in rows)
assert all(not r[-1] for r in festival_rows)
assert stats['xlsx_files']==202
(ROOT/'validation.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2),encoding='utf-8')
archive=OUT/'HappyRoom_Ngay_le_195_quoc_gia_2026_2027.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    for p in ROOT.rglob('*'):
        if p.is_file(): z.write(p,p.relative_to(OUT))
print(json.dumps(stats,ensure_ascii=False,indent=2)); print('Archive:',archive,archive.stat().st_size)
