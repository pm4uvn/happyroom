Mục đích: Dữ liệu nền cho HappyRoom mở rộng từ sinh nhật sang ngày lễ và sự kiện theo quốc gia. Đây là bản tham khảo có cờ rà soát, chưa phải lịch chính thức đã duyệt.

Phạm vi quốc gia: 195 quốc gia: 193 thành viên Liên Hợp Quốc + Tòa Thánh/Vatican (VA) + Nhà nước Palestine (PS). Không gồm toàn bộ lãnh thổ phụ thuộc và các thực thể khác.

Châu lục: 6 nhóm: Á, Âu, Phi, Bắc Mỹ (gồm Trung Mỹ và Caribe), Nam Mỹ, Đại Dương. Không có quốc gia ở Nam Cực. Phân vùng theo mledoze/countries; nước xuyên lục địa chỉ xuất hiện trong một nhóm để tránh lặp.

Khoảng thời gian: Ngày cụ thể trong 2026 và 2027. Không mặc định các ngày giống nhau giữa hai năm là ngày cố định.

Nguồn ngày lễ: Python holidays phiên bản 0.108, danh mục PUBLIC mặc định, observed=True; nguồn mã theo quốc gia và tài liệu tham chiếu được ghi trong Nguon.

Giới hạn: Bao phủ đủ danh mục 195 quốc gia không đồng nghĩa đầy đủ mọi lễ hội. Không bao quát toàn bộ lễ địa phương, lễ của cộng đồng thiểu số, lễ mới công bố, nghỉ bù đột xuất hoặc sự kiện thương mại.

Nguồn lễ hội: Sheet Le_hoi_bo_sung là danh mục chọn lọc với mô tả biên tập và link tham khảo; nguồn và lịch tổ chức chưa được kiểm chứng độc lập. Ngày trống nghĩa là chưa xác định, không phải không tổ chức.

Ý nghĩa: Mô tả tiếng Việt được biên tập theo nhóm ý nghĩa từ tên sự kiện; không phải bản dịch nguyên văn hay lịch sử riêng đã kiểm chứng. Dòng thiếu thuyết minh được gắn trạng thái riêng.

Lễ tôn giáo: Nằm trong Ngay_le nếu nguồn coi là ngày PUBLIC. Có thể lọc Loại = Tôn giáo hoặc Lễ hội. Sheet Le_hoi_bo_sung bổ sung lễ hội văn hóa ngoài ngày nghỉ công cộng.

Ngày nghỉ bù: So sánh lịch observed=True với observed=False kết hợp nhãn nguồn. Đây là phân loại tự động, cần duyệt; không nên coi ngày nghỉ bù là ngày kỷ niệm gốc.

Ngày ước tính: Cờ dựa trên nhãn estimated/tentative của thư viện; FALSE không có nghĩa đã được cơ quan địa phương xác nhận. Ngày Hồi giáo có thể đổi theo quan sát trăng.

An toàn nội dung: Các dịp tưởng niệm, quốc tang hoặc chay tịnh cần nội dung trang trọng; không tự động dùng pháo giấy, lời chúc ăn mừng hay thông báo vui nhộn.

Tự động hóa: auto_celebrate = FALSE và Đã duyệt nguồn chính thức = FALSE cho toàn bộ bản nháp. Sau khi duyệt, chọn riêng hiển thị thông tin / lời chúc / tưởng niệm, không bật cùng một hiệu ứng cho mọi loại sự kiện.

Múi giờ: Lưu IANA timezone của người dùng / địa phương. Một nước có thể nhiều múi giờ; không áp dụng một UTC offset cho toàn quốc. So sánh ngày theo timezone trước khi gửi.

Chống trùng: event_id phân biệt từng lần xuất hiện theo quốc gia + ngày + tên. Dùng thêm khóa người dùng + event_id để gửi một lần. Một ngày có thể có nhiều sự kiện.

Lặp hằng năm: event_id không phải mã chuỗi sự kiện vĩnh viễn. Nếu cần tái diễn, tạo series_id và quy tắc riêng sau khi duyệt; cập nhật dữ liệu cho năm mới thay vì sao chép ngày.

Kiểm chứng trước khi dùng: Đối chiếu nguồn chính phủ / cơ quan tổ chức; xác minh ngày thực tế và nghỉ bù, phạm vi địa phương, ngôn ngữ, ý nghĩa, bản quyền và lựa chọn nhận thông báo của người dùng.

Ngày tổng hợp: 2026-11-07. Phiên bản thư viện được cố định trong nguồn đi kèm để có thể tái tạo.

Định dạng: Ngày là ô ngày Excel (yyyy-mm-dd), ISO2 là mã quốc gia, Boolean là TRUE/FALSE; ô trống là chưa có dữ liệu. Mỗi file có bộ lọc, dòng tiêu đề cố định và danh mục nguồn.

Cập nhật: Rà soát hằng năm và khi có thông báo mới từ chính quyền. Danh mục PUBLIC của thư viện không thay thế văn bản pháp lý về ngày nghỉ.